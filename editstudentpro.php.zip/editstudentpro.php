<?php
include "../include/config.php";
$state='Lagos';
$thestateid=$setup->getstatesbyid($state)->fetch(PDO::FETCH_ASSOC);
$stdstate=$thestateid['state_id'];
?>

<!DOCTYPE html>
<html lang="en">
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <title>EDIT||PROFILE</title>

    <!-- BEGIN META -->

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="keywords" content="your,keywords">
    <meta name="description" content="Short explanation about this website">
    <!-- END META -->

    <!-- BEGIN STYLESHEETS -->
    <link href='http://fonts.googleapis.com/css?family=Roboto:300italic,400italic,300,400,500,700,900' rel='stylesheet' type='text/css'/>
    <link type="text/css" rel="stylesheet" href="../assets/css/theme-default/bootstrap.css?1422792965" />
    <link type="text/css" rel="stylesheet" href="../assets/css/theme-default/materialadmin.css?1425466319" />
    <link type="text/css" rel="stylesheet" href="../assets/css/theme-default/font-awesome.min.css?1422529194" />
    <link type="text/css" rel="stylesheet" href="../assets/css/theme-default/material-design-iconic-font.min.css?1421434286" />
    <!-- END STYLESHEETS -->
    <style>

        #classlabeldesign,#labeldesign{
            width: 13%;
            margin-left: 1px;
            float: left;
            text-align: left;
            font-weight: bold;
            font-size: 11px;
            color: #000;
            opacity: 1;
        }


        .form-control,h3{
            font-size: 13px;
            opacity: 3;
            color: #000;

        }


        ul#nav {
            list-style-type: none;
            margin: 0;
            padding: 0;
            overflow: hidden;
            border: 0px solid #e7e7e7;
            background-color: #f3f3f3;

        }

        li#thenav {
            float: left;

        }

        li#thenav a {
            display: block;
            color: black;
            text-align: center;
            padding: 14px 10px;
            text-decoration: none;
            font-weight: bold;


        }

        

        li#thenav a.active {
            color: white;
            background-color: #4CAF50;
        }
        #allbiodata,#allstudentstatus,#allcontact,#allnextofkin,#allupload{
            display:none;
        }
        .selectedcourse{
            background-color:#cdcdcd;
            
            
        }
        .closeform {
            cursor: pointer;

        }
         h3,h4,h5,h6,h1,h2{
            margin-top:0px;
            margin-bottom:0px;
        }
        #content {
        position: relative;
        width: 100%;
        left: 0px;
        padding-top: 1px;
        margin-top:0px;
        margin-left:-90px;
        }
        #base{
            padding-left:0px;
        }
       
    

    </style>
    <link type="text/css" href="../assets/jquery/themes/base/ui.base.css" rel="stylesheet" />
    <link type="text/css" href="../assets/jquery/themes/base/ui.theme.css" rel="stylesheet" />
    <link type="text/css" rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" />
    <script language="javascript" src="../assets/jquery/jquery.js" ></script>
    <script language="javascript" src="../assets/js/jquery.form.min.js"></script>
    <script language="javascript" src="../assets/jquery/ui/ui.core.js"></script>
    <script language="javascript" src="../assets/jquery/ui/ui.datepicker.js"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css" rel="stylesheet" />
    <script>
        $.noConflict();
        jQuery(document).ready(function ($) {
            $("#TDATE").datepicker({dateFormat: 'dd-MM-yy'});
            $("#RDATE").datepicker({dateFormat: 'dd-MM-yy'});


        });
    </script>
</head>
<body class="menubar-hoverable header-fixed ">

<!-- BEGIN HEADER-->

<div id="base" >
    <div id="content">
        <section>
            <div class="section-body contain-md">
                <h4 class="text-center titleofform">Edit Student Record</h4>
                <h3 style="margin-left:100%"><span class="text-left closeform"><i class="fa fa-window-close" aria-hidden="true"></i></span></h3>
                <div class="card">
                    <div class="card-body" style="max-height: 500px;overflow-y: scroll;">
                        <form  id="form"  class="form-horizontal"  method= "POST" action=""  role="form" enctype="multipart/form-data" autocomplete="off">
                            <div class="form-group">
                                <label for="nmlist" id="labeldesign" class="col-sm-2 control-label">Name</label>
                                <div class="col-sm-5">
                                   <select name="addno"  id="addno" class="form-control" required>
                                        <option value="">Select Student </option>
                                        <?php
                                        $getallstudentsinalevel=$setup->getallstudentsinalevel();
                                        foreach($getallstudentsinalevel as $allstudents){
                                            extract($allstudents);
                                            
                                            ?>
                                            <option value="<?php echo $ADDNO;?>" ><?php echo $allstudents["SURNAME"].'   ' . $allstudents["FIRSTNAME"].'   ' . $allstudents["OTHERNAME"];?></option>
                                            <?php
                                        }
                                        ?>
                                    </select>

                                </div>
                                <div class="col-sm-2" style="margin-left:0px;" >
                                    <input type="button" name="save"  id="save" value="Search">
                                </div>
                                <div class="col-sm-2">
                                    <input type="button" name="saveupload"  id="saveupload" value="Save Update">
                                </div>
                            </div>
                            <ul id="nav">
                                <li id="thenav" ><a  href="#home" id="biodata">Biodata</a></li>
                                <li id="thenav"><a href="#about" id="studentship">Studentship</a></li>
                                <li id="thenav"><a href="#contact" id="contact">Contact</a></li>
                                <li  id="thenav" ><a href="#about" id="nok">Next of Kin</a></li>
                                <li id="thenav"><a href="#news" id="upload">Uploads</a></li>
                            </ul>
                            <div id="allbiodata">
                              
                            </div>

                            <div id="allstudentstatus">
                              
                            </div>

                            
                            <div id="allcontact">
                                
                            </div>
                            <div id="allnextofkin">
                                
                            </div>
                            <div id="allupload">
                    
                            </div>

                        </form>
                    </div>
                </div>
            </div>
        </section>
    </div>
</div>
<div class="modal fade" id="msgdetails" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog modal-lg">
        <div class="modal-content" role="document">
            <div class="col-sm-12" id="theresponse">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" id="theexit" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="successdetails" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog">
        <div class="modal-content" role="document">
            <div class="modal-header">
                <button type="button" id="successclose" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title text-center" id="myModalLabel">Message</h4>
            </div>
            <div class="modal-body">
                <p id="successalert"></p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" id="successexit" data-dismiss="modal">Ok</button>
            </div>
        </div>
    </div>
</div>
<!-- BEGIN JAVASCRIPT -->

<script src="../assets/js/libs/jquery/jquery-1.11.2.min.js"></script>
<script src="../assets/js/libs/jquery/jquery-migrate-1.2.1.min.js"></script>
<script src="../assets/js/libs/bootstrap/bootstrap.min.js"></script>
<script src="../assets/js/libs/spin.js/spin.min.js"></script>
<script src="../assets/js/libs/autosize/jquery.autosize.min.js"></script>
<script src="../assets/js/libs/nanoscroller/jquery.nanoscroller.min.js"></script>
<script src="../assets/js/core/source/App.js"></script>
<script src="../assets/js/core/source/AppNavigation.js"></script>
<script src="../assets/js/core/source/AppOffcanvas.js"></script>
<script src="../assets/js/core/source/AppCard.js"></script>
<script src="../assets/js/core/source/AppForm.js"></script>
<script src="../assets/js/core/source/AppNavSearch.js"></script>
<script src="../assets/js/core/source/AppVendor.js"></script>
<script src="../assets/js/core/demo/Demo.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>
<!-- END JAVASCRIPT -->
</body>
</html>
<script type="text/javascript">
    $('#addno').select2();
    $('#COUNTRY').select2();
    $(".closeform").click(function(){
        $('#base').hide();
        $('.closeform').hide();
        $('.titleofform').hide(); 
        
    });
    function getstudentdetails(){
        var addno=$.trim($("#addno").val());
        //alert(addno);
        $.ajax({
            url:"studentprofilecontrol.php",
            type:'POST',
            dataType:'JSON',
            data:{addno:addno,dataname:'geteditprofile'},
            success:function(studentprofile){
            //alert(studentprofile.stdcontact);
            $("#allupload").html(studentprofile.stdupload);
            //$("#allnextofkin").html(studentprofile.stdnok);
            $("#allbiodata").html(studentprofile.stdbio);
            $("#allcontact").html(studentprofile.stdcontact);
            $("#allstudentstatus").html(studentprofile.studentstatus);
                
            }
        });
    }
    
    $("#allbiodata").hide();
    $("#allstudentstatus").hide();
    $("#allcontact").hide();
    $("#allnextofkin").hide();
    $("#allupload").hide();
    $("#biodata").click(function(){
        var biodata = $(this).attr("id");
        $("#allstudentstatus").removeClass('selectedcourse');
        $(this).addClass('selectedcourse');
        $("#allstudentstatus").removeClass('selectedcourse');
        $("#nok").removeClass('selectedcourse');
        $("#upload").removeClass('selectedcourse');
        $("#studentship").removeClass('selectedcourse');
        $("#contact").removeClass('selectedcourse');
        $("#allbiodata").slideToggle();
        $("#allstudentstatus").hide();
        $("#allcontact").hide();
        $("#allnextofkin").hide();
        $("#allupload").hide();
    });
    $("#studentship").click(function(){
        var studentship = $(this).attr("id");
        $(this).addClass('selectedcourse');
        $("#allbiodata").hide();
        $("#allcontact").hide();
        $("#allnextofkin").hide();
        $("#allstudentstatus").slideToggle();
        $("#allupload").hide();
        $(this).addClass('selectedcourse');
        $("#biodata").removeClass('selectedcourse');
        $("#upload").removeClass('selectedcourse');
        $("#contact").removeClass('selectedcourse');
        $("#nok").removeClass('selectedcourse');
    });
    $("#contact").click(function(){
        var contact = $(this).attr("id");
        $(this).addClass('selectedcourse');
        $("#allcontact").slideToggle();
        $("#allbiodata").hide();
        $("#allnextofkin").hide();
        $("#allstudentstatus").hide();
        $("#allupload").hide();
        $(this).addClass('selectedcourse');
        $("#biodata").removeClass('selectedcourse');
        $("#upload").removeClass('selectedcourse');
        $("#studentship").removeClass('selectedcourse');
        $("#nok").removeClass('selectedcourse');
    });
    $("#nok").click(function(){
        var nok = $(this).attr("id");
        $(this).addClass('selectedcourse');
        //$(this).addClass('selectedcourse');
        $("#allnextofkin").slideToggle();
        $("#allbiodata").hide();
        $("#allcontact").hide();
        $("#allstudentstatus").hide();
        $("#allupload").hide();

        
        $(this).addClass('selectedcourse');
        $("#biodata").removeClass('selectedcourse');
        $("#upload").removeClass('selectedcourse');
        $("#studentship").removeClass('selectedcourse');
        $("#contact").removeClass('selectedcourse');

        // $("#allbiodata").removeClass('selectedcourse');
        // $("#allcontact").removeClass('selectedcourse');
        // $("#allstudentstatus").removeClass('selectedcourse');
        // $("#allupload").removeClass('selectedcourse');
    });
    $("#upload").click(function(){
        var upload = $(this).attr("id");
        $(this).addClass('selectedcourse');
        $("#allupload").slideToggle();
        $("#allnextofkin").hide();
        $("#allbiodata").hide();
        $("#allcontact").hide();
        $("#allstudentstatus").hide();

        $(this).addClass('selectedcourse');
        $("#biodata").removeClass('selectedcourse');
        $("#nok").removeClass('selectedcourse');
        $("#studentship").removeClass('selectedcourse');
        $("#contact").removeClass('selectedcourse');

        // $("#allnextofkin").removeClass('selectedcourse');
        // $("#allbiodata").removeClass('selectedcourse');
        // $("#allcontact").removeClass('selectedcourse');
        // $("#allstudentstatus").removeClass('selectedcourse');
    });
    $(document).on('change', '#COUNTRY', function(){
        var COUNTRY=$("#COUNTRY").val(); 
        //alert(COUNTRY);
        if(COUNTRY!=='Nigeria'){
            var state=$("#STATE").empty(); 
            var lga=$("#LGA").empty();
            $("#STATE").attr('disabled','disabled'); 
            $("#LGA").attr('disabled','disabled'); 
        }else{
            var addno=$.trim($("#addno").val());
            $.ajax({
                url:"studentprofilecontrol.php",
                type:'POST',
                dataType:'JSON',
                data:{addno:addno,dataname:'geteditprofile'},
                success:function(studentprofile){
                    //alert(studentprofile.stdcontact);
                    $("#allupload").html(studentprofile.stdupload);
                    //$("#allnextofkin").html(studentprofile.stdnok);
                    $("#allbiodata").html(studentprofile.stdbio);
                    $("#allcontact").html(studentprofile.stdcontact);
                    $("#allstudentstatus").html(studentprofile.studentstatus);
                    
                }
            });
        }
    });

    $(document).on('change', '#STATE', function(){
        var state=$("#STATE").val(); 
        //alert(state);
        if(state!==''){
            $.ajax({
                url:"studentprofilecontrol.php",
                type:'POST',
                dataType:'text',
                data:{state:state,dataname:'getthestatelga'},
                success:function(response){
                   $("#LGA").html(response);


                    
            }
           });
        }
    });
    $(document).on('change', '#LEVEL', function(){
        var studylevel=$("#LEVEL").val(); 
        //alert(studylevel);
        if(studylevel!==''){
            $.ajax({
                url:"studentprofilecontrol.php",
                type:'POST',
                dataType:'text',
                data:{studylevel:studylevel,dataname:'getallclassbylevel'},
                success:function(response){
                   $("#CLASS").html(response);


                    
            }
           });
        }
    });
    $(document).on('change', '#program', function(){
        var program=$("#program").val(); 
        //alert(program);
        if(program!==''){
            $.ajax({
                url:"editstudentcontrol.php",
                type:'POST',
                dataType:'JSON',
                data:{program:program,dataname:'getbyprogram'},
                success:function(theprogram){
                    //alert(response);
                    $("#dept").val(theprogram.dept);
                    $("#college").val(theprogram.college);

                       
                }
            });
        }
    });
    $("#save").click(function(){
        var addno=$.trim($("#addno").val());
        //alert(addno);
        $.ajax({
            url:"studentprofilecontrol.php",
            type:'POST',
            dataType:'JSON',
            data:{addno:addno,dataname:'geteditprofile'},
            success:function(studentprofile){
            //alert(studentprofile.stdcontact);
            $("#allupload").html(studentprofile.stdupload);
            //$("#allnextofkin").html(studentprofile.stdnok);
            $("#allbiodata").html(studentprofile.stdbio);
            $("#allcontact").html(studentprofile.stdcontact);
            $("#allstudentstatus").html(studentprofile.studentstatus);
             $("#allbiodata").show();
                
            }
        });
    });
    function IsEmail(email) {
        var regex = /^([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
        if(!regex.test(email)) {
            return false;
        }else{
            return true;
        }
    }
    $("#saveupload").click(function(){
        var addno=$.trim($("#addno").val());
        var SURNAME=$.trim($("#SURNAME").val());
        var FIRSTNAME=$.trim($("#FIRSTNAME").val());
        var OTHERNAME=$.trim($("#OTHERNAME").val());
        var SEX=$.trim($("#SEX").val());
        var DOB=$.trim($("#DOB").val());
        var COUNTRY=$.trim($("#COUNTRY").val());
        var STATE=$.trim($("#STATE").val());
        var LGA=$.trim($("#LGA").val());
        var HTOWN=$.trim($("#HTOWN").val());
        var PSURNAME=$.trim($("#PSURNAME").val());
        var POTHERNAME=$.trim($("#POTHERNAME").val());
        var PADDRESS=$.trim($("#PADDRESS").val());
        var PTOWN=$.trim($("#PTOWN").val());
        var PEMAIL=$.trim($("#PEMAIL").val());
        var PSTATE=$.trim($("#PSTATE").val());
        //var PEMAIL=$('#PEMAIL').text();
        var RELATIONSHIP=$.trim($("#RELATIONSHIP").val());
        var PPHONENO=$.trim($("#PPHONENO").val());
        var LEVEL=$.trim($("#LEVEL").val());
        var CLASS=$.trim($("#CLASS").val());
        //var OLDPHOTO = $('#OLDPHOTO').prop('files')[0];
        //var NEWPHOTO = $('#NEWPHOTO').prop('files')[0];
        //alert(NEWPHOTO);
        // var regstatus=$.trim($("#regstatus").val());
        // var resultstatus=$.trim($("#resultstatus").val());
        // var discplinary=$.trim($("#discplinary").val());
        // var studstatus=$.trim($("#studstatus").val());
        // var clearancestatus=$.trim($("#clearancestatus").val());
        // var madres1=$.trim($("#madres1").val());
        // var madres2=$.trim($("#madres2").val());
        // var madres3=$.trim($("#madres3").val());
        // var stdemail=$.trim($("#stdemail").val());
        // var cumail=$.trim($("#cumail").val());
        // var ptitle=$.trim($("#ptitle").val());
        // var pname=$.trim($("#pname").val());
        // var nokname=$.trim($("#nokname").val());
        // var nokaddress1=$.trim($("#nokaddress1").val());
        // var nokaddress2=$.trim($("#nokaddress2").val());
        // var nokaddress3=$.trim($("#nokaddress3").val());
        // var nokemail=$.trim($("#nokemail").val());
        // var nokphone1=$.trim($("#nokphone1").val());
        // var nokphone2=$.trim($("#nokphone2").val()); 
        // var nokphone3=$.trim($("#nokphone3").val());
        // var studylevel=$.trim($("#studylevel").val());
        // if(IsEmail(cumail)==false ||  IsEmail(stdemail)==false || IsEmail(nokemail)==false ){
        //     alert('Invalid email format');
        // }else{

            $.ajax({
                url:"studentprofilecontrol.php",
                type:'POST',
                dataType:'text',
                data:{addno:addno,SURNAME:SURNAME,FIRSTNAME:FIRSTNAME,OTHERNAME:OTHERNAME,SEX:SEX,DOB:DOB,
                COUNTRY:COUNTRY,STATE:STATE,LGA:LGA,HTOWN:HTOWN,PSURNAME:PSURNAME,
                POTHERNAME:POTHERNAME,PADDRESS:PADDRESS,PTOWN:PTOWN,PEMAIL:PEMAIL,PSTATE:PSTATE,
                RELATIONSHIP:RELATIONSHIP,PPHONENO:PPHONENO,
                LEVEL:LEVEL,CLASS:CLASS,dataname:'updatestddetails'},
                success:function(response){
                    alert(response);
                    window.location.href="editstudentpro.php";
                    //getstudentdetails();

                    
                }
            });
        //}
    });
    function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#blah')
                        .attr('src', e.target.result)
                        .width(150)
                        .height(200);
                };

                reader.readAsDataURL(input.files[0]);
            }
        }
</script>

